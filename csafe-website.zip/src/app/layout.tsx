import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "C-Safe Wellness Group | Executive Mental Health & Wellness Advisory",
  description:
    "Discreet, high-touch B2B wellness advisory for C-suite teams. Executive treatment placement, crisis response, monthly leadership wellness programming, and leadership continuity — available upon request.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ fontFamily: "'Inter', sans-serif" }}>{children}</body>
    </html>
  );
}
